# ClusterFoldSimilarity
Calculate cluster similarity between clusters from different single cell datasets/batches/samples.
